# Drawing Board – Instant Whiteboard Overlay

A Manifest V3 Chrome extension that turns any webpage into an instant
diagramming canvas. Press **Alt+D** (or **Cmd+Shift+D** on Mac) or click the
toolbar icon, and a full-page whiteboard overlay appears on top of the tab
you're already looking at — no new tab, no account, nothing to configure.

Built by **[Faiz Azizan](https://drfaizazizan.com)**

---

## ✨ Features

- **Shapes** — rectangle, rounded rectangle, ellipse, diamond (decision node)
- **Connectors** — straight arrow, line, and curved line, with automatic
  snap-to-anchor so connectors stay attached to shapes as you move them
- **Freehand pen & highlighter**
- **Text notes** — double-click to type, click away to save
- **Two board modes** — Transparent Overlay (draw on top of the live page)
  or Grid / Dot Board (clean whiteboard backdrop)
- **Select, drag, resize** any shape with corner handles
- **Undo / redo** (`Ctrl+Z` / `Ctrl+Shift+Z`)
- **Draggable toolbar** — move it anywhere on screen, position is remembered
- **Minimize / restore** with one click
- **Auto-save per page** — your board persists per URL via
  `chrome.storage.local`
- **Export** as PNG, SVG, or raw JSON
- Nord-inspired minimalist color palette
- Fully isolated via **Shadow DOM** — the overlay's styles never leak into,
  or get overridden by, the host page's CSS

## 📦 Installation (Developer Mode)

1. Clone or download this repo.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select this project's folder.
5. Pin the extension icon, then click it (or press `Alt+D`) on any webpage.

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Alt+D` (Win/Linux) / `Cmd+Shift+D` (Mac) | Toggle the overlay on the active tab |
| `Ctrl+Z` / `Cmd+Z` | Undo |
| `Ctrl+Shift+Z` / `Cmd+Shift+Z` | Redo |
| `Delete` / `Backspace` | Delete selected element |
| `Esc` | Deselect / return to Select tool |

You can rebind the toggle shortcut anytime at `chrome://extensions/shortcuts`.

## 🗂️ Project Structure

```
drawing-board-extension/
├── manifest.json      # MV3 manifest — permissions, commands, icons
├── background.js      # Service worker — handles icon click & shortcut, injects content.js
├── content.js          # Shadow DOM canvas engine, toolbar, undo/redo, export, persistence
├── styles.css          # Scoped styles for the overlay (loaded into the Shadow DOM)
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

## 🔐 Permissions

| Permission | Why it's needed |
|---|---|
| `activeTab` | Only acts on the tab you're currently viewing, only when you explicitly click the icon or use the shortcut |
| `scripting` | Injects the drawing canvas and toolbar into the active tab on trigger |
| `storage` | Saves your drawings (per page URL) and toolbar position locally via `chrome.storage.local` |

No host permissions, no remote code, no analytics, no network calls other
than loading the extension's own bundled `styles.css`.

## 🔒 Privacy

Drawing Board collects nothing and has no backend. Everything you draw stays
on your device in `chrome.storage.local` and is never transmitted anywhere.
Full policy: [`privacy-policy.html`](./privacy-policy.html) ·
[`privacy-policy.txt`](./privacy-policy.txt)

## 🧭 Roadmap Ideas

- [ ] Multi-page board switcher (not just current URL)
- [ ] Shape library presets (flowchart symbols, UML basics)
- [ ] Keyboard-only shape creation
- [ ] Cross-device sync via `chrome.storage.sync` (opt-in)

## 📄 License

*(Not yet specified — add a `LICENSE` file, e.g. MIT, if you want this repo
to be reusable by others. Currently all rights reserved by default until a
license is added.)*

## 🙌 Credits

Built and maintained by **[Faiz Azizan](https://drfaizazizan.com)** — FA
Analytics.
