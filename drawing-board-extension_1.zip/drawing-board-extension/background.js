// background.js — MV3 service worker for Drawing Board
// Responsible for: (1) reacting to the action icon click, (2) reacting to the
// Alt+D / Cmd+Shift+D keyboard shortcut, (3) deciding whether content.js
// needs to be injected for the first time, or whether we can just message an
// already-running instance to toggle its visibility.

const BLOCKED_PREFIXES = [
  'chrome://',
  'chrome-extension://',
  'edge://',
  'about:',
  'https://chrome.google.com/webstore',
  'https://chromewebstore.google.com'
];

function isInjectable(url) {
  if (!url) return false;
  return !BLOCKED_PREFIXES.some((prefix) => url.startsWith(prefix));
}

async function pingTab(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: 'WB_PING' });
    return !!(response && response.alive);
  } catch (e) {
    // No listener yet — content script has never been injected on this tab.
    return false;
  }
}

async function toggleOverlay(tab) {
  if (!tab || !tab.id) return;
  if (!isInjectable(tab.url)) {
    console.warn('Drawing Board: cannot run on this page:', tab.url);
    return;
  }

  try {
    const alreadyRunning = await pingTab(tab.id);

    if (alreadyRunning) {
      await chrome.tabs.sendMessage(tab.id, { type: 'WB_TOGGLE' });
      return;
    }

    // Not yet injected on this tab (or the tab was reloaded, which wipes
    // any previously injected script) — inject fresh.
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch (err) {
    console.error('Drawing Board: failed to toggle on tab', tab.id, err);
  }
}

chrome.action.onClicked.addListener((tab) => {
  toggleOverlay(tab);
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command === 'toggle-overlay') {
    toggleOverlay(tab);
  }
});
