// content.js — Drawing Board (Instant Whiteboard Overlay)
// Runs inside the page's world but isolated visually via Shadow DOM.
(function () {
  if (window.__wbOverlayInitialized) {
    // Safety net: background.js already pings before re-injecting, so this
    // branch should not normally run, but we guard anyway.
    window.__wbOverlayApi && window.__wbOverlayApi.toggleVisibility();
    return;
  }
  window.__wbOverlayInitialized = true;

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const STORAGE_PREFIX = 'wbOverlay::';
  const NORD = [
    '#2E3440', '#3B4252', '#434C5E', '#4C566A',
    '#D8DEE9', '#E5E9F0', '#ECEFF4',
    '#8FBCBB', '#88C0D0', '#81A1C1', '#5E81AC',
    '#BF616A', '#D08770', '#EBCB8B', '#A3BE8C', '#B48EAD'
  ];
  const ANCHOR_SNAP_PX = 14;

  function uid() {
    return 'el_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  function storageKeyForUrl() {
    return STORAGE_PREFIX + location.origin + location.pathname + location.search;
  }

  function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  // ---------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------
  const state = {
    visible: true,
    mode: 'transparent', // 'transparent' | 'grid'
    tool: 'select',
    color: '#2E3440',
    strokeWidth: 2,
    filled: false,
    elements: [],
    selectedId: null,
    history: [],
    historyIndex: -1
  };

  let drag = null; // active pointer interaction descriptor

  // ---------------------------------------------------------------------
  // Host + Shadow DOM
  // ---------------------------------------------------------------------
  const host = document.createElement('div');
  host.id = 'wb-overlay-host-84f2c1';
  host.style.all = 'initial';
  host.style.position = 'fixed';
  host.style.inset = '0';
  host.style.zIndex = '2147483647';
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: 'open' });

  fetch(chrome.runtime.getURL('styles.css'))
    .then((r) => r.text())
    .then((css) => {
      const styleEl = document.createElement('style');
      styleEl.textContent = css;
      shadow.appendChild(styleEl);
    })
    .catch((e) => console.error('Drawing Board: failed to load styles.css', e));

  const root = document.createElement('div');
  root.id = 'wb-root';
  root.className = 'wb-mode-transparent';
  shadow.appendChild(root);

  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.id = 'wb-canvas';
  svg.setAttribute('width', '100%');
  svg.setAttribute('height', '100%');
  root.appendChild(svg);

  const defs = document.createElementNS(SVG_NS, 'defs');
  svg.appendChild(defs);
  ['wb-arrowhead', 'wb-arrowhead-sel'].forEach((id, i) => {
    const marker = document.createElementNS(SVG_NS, 'marker');
    marker.setAttribute('id', id);
    marker.setAttribute('viewBox', '0 0 10 10');
    marker.setAttribute('refX', '9');
    marker.setAttribute('refY', '5');
    marker.setAttribute('markerWidth', '7');
    marker.setAttribute('markerHeight', '7');
    marker.setAttribute('orient', 'auto-start-reverse');
    const path = document.createElementNS(SVG_NS, 'path');
    path.setAttribute('d', 'M0,0 L10,5 L0,10 z');
    path.setAttribute('fill', i === 1 ? '#5E81AC' : 'context-stroke');
    marker.appendChild(path);
    defs.appendChild(marker);
  });

  const elementsLayer = document.createElementNS(SVG_NS, 'g');
  elementsLayer.id = 'wb-elements-layer';
  svg.appendChild(elementsLayer);

  const overlayLayer = document.createElementNS(SVG_NS, 'g');
  overlayLayer.id = 'wb-overlay-layer'; // selection handles, live drag preview
  svg.appendChild(overlayLayer);

  const editorLayer = document.createElement('div');
  editorLayer.id = 'wb-editor-layer'; // contenteditable text editing surface
  root.appendChild(editorLayer);

  // ---------------------------------------------------------------------
  // Toolbar
  // ---------------------------------------------------------------------
  const toolbar = document.createElement('div');
  toolbar.id = 'wb-toolbar';
  root.appendChild(toolbar);

  const dragHandle = document.createElement('div');
  dragHandle.className = 'wb-drag-handle';
  dragHandle.title = 'Drag to move toolbar';
  dragHandle.textContent = '\u22EE\u22EE';
  toolbar.appendChild(dragHandle);

  const TOOL_GROUPS = [
    {
      label: 'Tool',
      items: [
        { tool: 'select', label: 'Select', glyph: '\u2196' },
        { tool: 'rect', label: 'Rectangle', glyph: '\u25AD' },
        { tool: 'roundrect', label: 'Rounded Rect', glyph: '\u25A2' },
        { tool: 'ellipse', label: 'Ellipse', glyph: '\u25EF' },
        { tool: 'diamond', label: 'Decision', glyph: '\u25C7' }
      ]
    },
    {
      label: 'Connect',
      items: [
        { tool: 'arrow', label: 'Arrow', glyph: '\u2192' },
        { tool: 'line', label: 'Line', glyph: '\u2500' },
        { tool: 'curve', label: 'Curve', glyph: '\u007E' }
      ]
    },
    {
      label: 'Draw',
      items: [
        { tool: 'text', label: 'Text', glyph: 'T' },
        { tool: 'pen', label: 'Pen', glyph: '\u270E' },
        { tool: 'highlighter', label: 'Highlighter', glyph: '\u2589' }
      ]
    }
  ];

  const toolButtons = {};

  TOOL_GROUPS.forEach((group) => {
    const groupEl = document.createElement('div');
    groupEl.className = 'wb-group';
    group.items.forEach((item) => {
      const btn = document.createElement('button');
      btn.className = 'wb-btn wb-tool-btn';
      btn.type = 'button';
      btn.title = item.label;
      btn.textContent = item.glyph;
      btn.addEventListener('click', () => setTool(item.tool));
      toolButtons[item.tool] = btn;
      groupEl.appendChild(btn);
    });
    toolbar.appendChild(groupEl);
  });

  // Color palette
  const colorGroup = document.createElement('div');
  colorGroup.className = 'wb-group wb-color-group';
  NORD.slice(0, 12).forEach((c) => {
    const swatch = document.createElement('button');
    swatch.className = 'wb-swatch';
    swatch.type = 'button';
    swatch.style.background = c;
    swatch.title = c;
    swatch.addEventListener('click', () => {
      state.color = c;
      updateSwatchSelection();
      if (state.selectedId) {
        const el = getElement(state.selectedId);
        if (el) {
          el.color = c;
          renderAll();
          pushHistory();
          persist();
        }
      }
    });
    swatch.dataset.color = c;
    colorGroup.appendChild(swatch);
  });
  toolbar.appendChild(colorGroup);

  function updateSwatchSelection() {
    colorGroup.querySelectorAll('.wb-swatch').forEach((s) => {
      s.classList.toggle('active', s.dataset.color.toLowerCase() === state.color.toLowerCase());
    });
  }

  // Mode toggle
  const actionGroup = document.createElement('div');
  actionGroup.className = 'wb-group';

  const modeBtn = document.createElement('button');
  modeBtn.className = 'wb-btn';
  modeBtn.type = 'button';
  modeBtn.title = 'Toggle Transparent Overlay / Grid Board';
  modeBtn.textContent = 'Board: Transparent';
  modeBtn.addEventListener('click', () => {
    state.mode = state.mode === 'transparent' ? 'grid' : 'transparent';
    applyMode();
    persist();
  });
  actionGroup.appendChild(modeBtn);

  const undoBtn = mkActionBtn('\u21B6', 'Undo', undo);
  const redoBtn = mkActionBtn('\u21B7', 'Redo', redo);
  const exportPngBtn = mkActionBtn('PNG', 'Export PNG', exportPNG);
  const exportSvgBtn = mkActionBtn('SVG', 'Export SVG', exportSVG);
  const exportJsonBtn = mkActionBtn('JSON', 'Export JSON', exportJSON);
  const deleteBtn = mkActionBtn('\u2715\u25A1', 'Delete selected (Del)', deleteSelected);
  const clearBtn = mkActionBtn('Clear', 'Clear board', clearBoard);
  [undoBtn, redoBtn, exportPngBtn, exportSvgBtn, exportJsonBtn, deleteBtn, clearBtn].forEach((b) =>
    actionGroup.appendChild(b)
  );
  toolbar.appendChild(actionGroup);

  const closeGroup = document.createElement('div');
  closeGroup.className = 'wb-group wb-close-group';
  const minimizeBtn = mkActionBtn('\u2212', 'Minimize', () => setPanelMinimized(true));
  const closeBtn = mkActionBtn('\u2715', 'Close overlay', () => setVisible(false));
  closeGroup.appendChild(minimizeBtn);
  closeGroup.appendChild(closeBtn);
  toolbar.appendChild(closeGroup);

  const reopenTab = document.createElement('button');
  reopenTab.id = 'wb-reopen-tab';
  reopenTab.type = 'button';
  reopenTab.textContent = '\u270E';
  reopenTab.title = 'Reopen whiteboard toolbar';
  reopenTab.addEventListener('click', () => setPanelMinimized(false));
  root.appendChild(reopenTab);

  // --- Free-drag toolbar positioning -----------------------------------
  const TOOLBAR_POS_KEY = 'wbOverlayToolbarPos'; // global, not per-URL — the
  // panel position is a UI preference, not page content, so it's shared
  // across every site rather than reset per-page like the drawings are.
  let toolbarDrag = null;

  function applyToolbarPosition(left, top) {
    const w = toolbar.offsetWidth || 480;
    const h = toolbar.offsetHeight || 44;
    const maxLeft = Math.max(8, window.innerWidth - w - 8);
    const maxTop = Math.max(8, window.innerHeight - h - 8);
    const clampedLeft = Math.max(8, Math.min(left, maxLeft));
    const clampedTop = Math.max(8, Math.min(top, maxTop));
    toolbar.style.left = clampedLeft + 'px';
    toolbar.style.top = clampedTop + 'px';
    toolbar.style.right = 'auto';
    toolbar.style.transform = 'none';
  }

  function saveToolbarPosition() {
    const rect = toolbar.getBoundingClientRect();
    chrome.storage.local.set({ [TOOLBAR_POS_KEY]: { left: rect.left, top: rect.top } });
  }

  function loadToolbarPosition() {
    chrome.storage.local.get([TOOLBAR_POS_KEY], (res) => {
      const pos = res[TOOLBAR_POS_KEY];
      if (pos && typeof pos.left === 'number' && typeof pos.top === 'number') {
        applyToolbarPosition(pos.left, pos.top);
      }
    });
  }

  dragHandle.addEventListener('mousedown', (evt) => {
    evt.preventDefault();
    evt.stopPropagation();
    const rect = toolbar.getBoundingClientRect();
    toolbarDrag = { offsetX: evt.clientX - rect.left, offsetY: evt.clientY - rect.top };
    dragHandle.classList.add('wb-dragging');
  });

  window.addEventListener('mousemove', (evt) => {
    if (!toolbarDrag) return;
    applyToolbarPosition(evt.clientX - toolbarDrag.offsetX, evt.clientY - toolbarDrag.offsetY);
  });

  window.addEventListener('mouseup', () => {
    if (!toolbarDrag) return;
    toolbarDrag = null;
    dragHandle.classList.remove('wb-dragging');
    saveToolbarPosition();
  });

  window.addEventListener('resize', () => {
    if (!toolbar.style.left) return; // still at default centered position
    const rect = toolbar.getBoundingClientRect();
    applyToolbarPosition(rect.left, rect.top);
  });

  function mkActionBtn(label, title, handler) {
    const b = document.createElement('button');
    b.className = 'wb-btn wb-action-btn';
    b.type = 'button';
    b.title = title;
    b.textContent = label;
    b.addEventListener('click', handler);
    return b;
  }

  function setPanelMinimized(min) {
    root.classList.toggle('wb-minimized', min);
  }

  function setTool(tool) {
    state.tool = tool;
    state.selectedId = null;
    Object.entries(toolButtons).forEach(([t, btn]) => btn.classList.toggle('active', t === tool));
    renderOverlayLayer();
    svg.dataset.tool = tool;
  }
  setTool('select');
  updateSwatchSelection();

  function applyMode() {
    root.classList.remove('wb-mode-transparent', 'wb-mode-grid');
    root.classList.add(state.mode === 'grid' ? 'wb-mode-grid' : 'wb-mode-transparent');
    modeBtn.textContent = state.mode === 'grid' ? 'Board: Grid' : 'Board: Transparent';
  }
  applyMode();

  // ---------------------------------------------------------------------
  // Persistence
  // ---------------------------------------------------------------------
  let persistTimer = null;
  function persist() {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => {
      const key = storageKeyForUrl();
      chrome.storage.local.set({
        [key]: {
          elements: state.elements,
          mode: state.mode,
          updatedAt: Date.now()
        }
      });
    }, 250);
  }

  function loadPersisted() {
    const key = storageKeyForUrl();
    chrome.storage.local.get([key], (res) => {
      const saved = res[key];
      if (saved) {
        state.elements = saved.elements || [];
        state.mode = saved.mode || 'transparent';
        applyMode();
        renderAll();
        pushHistory();
      } else {
        pushHistory();
      }
    });
  }

  // ---------------------------------------------------------------------
  // History (undo/redo) — snapshot based
  // ---------------------------------------------------------------------
  function pushHistory() {
    state.history = state.history.slice(0, state.historyIndex + 1);
    state.history.push(deepClone(state.elements));
    if (state.history.length > 60) state.history.shift();
    state.historyIndex = state.history.length - 1;
  }

  function undo() {
    if (state.historyIndex <= 0) return;
    state.historyIndex -= 1;
    state.elements = deepClone(state.history[state.historyIndex]);
    state.selectedId = null;
    renderAll();
    persist();
  }

  function redo() {
    if (state.historyIndex >= state.history.length - 1) return;
    state.historyIndex += 1;
    state.elements = deepClone(state.history[state.historyIndex]);
    state.selectedId = null;
    renderAll();
    persist();
  }

  function deleteSelected() {
    if (!state.selectedId) return;
    const id = state.selectedId;
    state.elements = state.elements.filter(
      (el) => el.id !== id && el.fromId !== id && el.toId !== id
    );
    state.selectedId = null;
    renderAll();
    pushHistory();
    persist();
  }

  function clearBoard() {
    if (!state.elements.length) return;
    if (!confirm('Clear the whole whiteboard for this page?')) return;
    state.elements = [];
    state.selectedId = null;
    renderAll();
    pushHistory();
    persist();
  }

  // ---------------------------------------------------------------------
  // Geometry helpers
  // ---------------------------------------------------------------------
  function getElement(id) {
    return state.elements.find((e) => e.id === id) || null;
  }

  function isBoxShape(el) {
    return ['rect', 'roundrect', 'ellipse', 'diamond', 'text'].includes(el.type);
  }

  function isConnector(el) {
    return ['arrow', 'line', 'curve'].includes(el.type);
  }

  function getAnchors(el) {
    const { x, y, w, h } = el;
    return {
      N: { x: x + w / 2, y: y },
      S: { x: x + w / 2, y: y + h },
      E: { x: x + w, y: y + h / 2 },
      W: { x: x, y: y + h / 2 },
      C: { x: x + w / 2, y: y + h / 2 }
    };
  }

  function resolveConnectorPoint(el, whichEnd) {
    const idKey = whichEnd === 'from' ? 'fromId' : 'toId';
    const anchorKey = whichEnd === 'from' ? 'fromAnchor' : 'toAnchor';
    if (el[idKey]) {
      const target = getElement(el[idKey]);
      if (target && isBoxShape(target)) {
        const anchors = getAnchors(target);
        const a = anchors[el[anchorKey]] || anchors.C;
        return { x: a.x, y: a.y };
      }
    }
    return whichEnd === 'from' ? { x: el.x1, y: el.y1 } : { x: el.x2, y: el.y2 };
  }

  function findShapeUnderPoint(px, py, excludeId) {
    for (let i = state.elements.length - 1; i >= 0; i--) {
      const el = state.elements[i];
      if (el.id === excludeId || !isBoxShape(el)) continue;
      if (px >= el.x && px <= el.x + el.w && py >= el.y && py <= el.y + el.h) {
        return el;
      }
    }
    return null;
  }

  function nearestAnchor(shape, px, py) {
    const anchors = getAnchors(shape);
    let best = null;
    let bestDist = Infinity;
    Object.entries(anchors).forEach(([key, pt]) => {
      if (key === 'C') return;
      const d = Math.hypot(pt.x - px, pt.y - py);
      if (d < bestDist) {
        bestDist = d;
        best = key;
      }
    });
    return { key: best, dist: bestDist, pt: anchors[best] };
  }

  function pointToSegmentDist(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const lenSq = dx * dx + dy * dy;
    let t = lenSq === 0 ? 0 : ((px - x1) * dx + (py - y1) * dy) / lenSq;
    t = Math.max(0, Math.min(1, t));
    const cx = x1 + t * dx;
    const cy = y1 + t * dy;
    return Math.hypot(px - cx, py - cy);
  }

  function hitTest(px, py) {
    for (let i = state.elements.length - 1; i >= 0; i--) {
      const el = state.elements[i];
      if (isBoxShape(el)) {
        if (px >= el.x && px <= el.x + el.w && py >= el.y && py <= el.y + el.h) return el;
      } else if (isConnector(el)) {
        const p1 = resolveConnectorPoint(el, 'from');
        const p2 = resolveConnectorPoint(el, 'to');
        if (pointToSegmentDist(px, py, p1.x, p1.y, p2.x, p2.y) <= 8) return el;
      } else if (el.type === 'pen' || el.type === 'highlighter') {
        const pts = el.points;
        for (let j = 0; j < pts.length - 1; j++) {
          if (pointToSegmentDist(px, py, pts[j].x, pts[j].y, pts[j + 1].x, pts[j + 1].y) <= 10) return el;
        }
      }
    }
    return null;
  }

  // ---------------------------------------------------------------------
  // Rendering
  // ---------------------------------------------------------------------
  function svgPointFromEvent(evt) {
    const rect = svg.getBoundingClientRect();
    return { x: evt.clientX - rect.left, y: evt.clientY - rect.top };
  }

  function makeShapeNode(el) {
    let node;
    if (el.type === 'rect' || el.type === 'roundrect') {
      node = document.createElementNS(SVG_NS, 'rect');
      node.setAttribute('x', el.x);
      node.setAttribute('y', el.y);
      node.setAttribute('width', Math.max(1, el.w));
      node.setAttribute('height', Math.max(1, el.h));
      if (el.type === 'roundrect') node.setAttribute('rx', 10);
    } else if (el.type === 'ellipse') {
      node = document.createElementNS(SVG_NS, 'ellipse');
      node.setAttribute('cx', el.x + el.w / 2);
      node.setAttribute('cy', el.y + el.h / 2);
      node.setAttribute('rx', Math.max(1, el.w / 2));
      node.setAttribute('ry', Math.max(1, el.h / 2));
    } else if (el.type === 'diamond') {
      node = document.createElementNS(SVG_NS, 'polygon');
      const { x, y, w, h } = el;
      const pts = [
        [x + w / 2, y],
        [x + w, y + h / 2],
        [x + w / 2, y + h],
        [x, y + h / 2]
      ]
        .map((p) => p.join(','))
        .join(' ');
      node.setAttribute('points', pts);
    }
    node.setAttribute('stroke', el.color);
    node.setAttribute('stroke-width', el.strokeWidth || 2);
    node.setAttribute('fill', el.filled ? el.color + '33' : 'transparent');
    return node;
  }

  function makeConnectorNode(el) {
    const p1 = resolveConnectorPoint(el, 'from');
    const p2 = resolveConnectorPoint(el, 'to');
    const node = document.createElementNS(SVG_NS, 'path');
    let d;
    if (el.type === 'curve') {
      const mx = (p1.x + p2.x) / 2;
      const my = (p1.y + p2.y) / 2;
      const dx = p2.y - p1.y;
      const dy = p1.x - p2.x;
      const norm = Math.hypot(dx, dy) || 1;
      const bend = Math.min(60, Math.hypot(p2.x - p1.x, p2.y - p1.y) / 3);
      const cx = mx + (dx / norm) * bend;
      const cy = my + (dy / norm) * bend;
      d = `M ${p1.x} ${p1.y} Q ${cx} ${cy} ${p2.x} ${p2.y}`;
    } else {
      d = `M ${p1.x} ${p1.y} L ${p2.x} ${p2.y}`;
    }
    node.setAttribute('d', d);
    node.setAttribute('stroke', el.color);
    node.setAttribute('stroke-width', el.strokeWidth || 2);
    node.setAttribute('fill', 'none');
    if (el.type === 'arrow') node.setAttribute('marker-end', 'url(#wb-arrowhead)');
    return node;
  }

  function makeFreehandNode(el) {
    const node = document.createElementNS(SVG_NS, 'polyline');
    node.setAttribute('points', el.points.map((p) => `${p.x},${p.y}`).join(' '));
    node.setAttribute('stroke', el.color);
    node.setAttribute('fill', 'none');
    node.setAttribute('stroke-linecap', 'round');
    node.setAttribute('stroke-linejoin', 'round');
    if (el.type === 'highlighter') {
      node.setAttribute('stroke-width', 16);
      node.setAttribute('opacity', '0.35');
    } else {
      node.setAttribute('stroke-width', el.strokeWidth || 3);
    }
    return node;
  }

  function makeTextNode(el) {
    const g = document.createElementNS(SVG_NS, 'g');
    const fo = document.createElementNS(SVG_NS, 'foreignObject');
    fo.setAttribute('x', el.x);
    fo.setAttribute('y', el.y);
    fo.setAttribute('width', Math.max(20, el.w));
    fo.setAttribute('height', Math.max(20, el.h));
    const div = document.createElement('div');
    div.className = 'wb-text-node';
    div.style.color = el.color;
    div.style.fontSize = (el.fontSize || 16) + 'px';
    div.textContent = el.text || 'Text';
    fo.appendChild(div);
    g.appendChild(fo);
    return g;
  }

  function renderAll() {
    elementsLayer.innerHTML = '';
    state.elements.forEach((el) => {
      let node;
      if (isBoxShape(el) && el.type !== 'text') node = makeShapeNode(el);
      else if (isConnector(el)) node = makeConnectorNode(el);
      else if (el.type === 'pen' || el.type === 'highlighter') node = makeFreehandNode(el);
      else if (el.type === 'text') node = makeTextNode(el);
      if (!node) return;
      node.dataset.id = el.id;
      node.classList.add('wb-el');
      node.addEventListener('mousedown', (evt) => onElementMouseDown(evt, el));
      node.addEventListener('dblclick', (evt) => onElementDblClick(evt, el));
      elementsLayer.appendChild(node);
    });
    renderOverlayLayer();
  }

  function renderOverlayLayer() {
    overlayLayer.innerHTML = '';
    if (!state.selectedId) return;
    const el = getElement(state.selectedId);
    if (!el) return;

    if (isBoxShape(el)) {
      const box = document.createElementNS(SVG_NS, 'rect');
      box.setAttribute('x', el.x - 4);
      box.setAttribute('y', el.y - 4);
      box.setAttribute('width', el.w + 8);
      box.setAttribute('height', el.h + 8);
      box.setAttribute('class', 'wb-selection-box');
      overlayLayer.appendChild(box);

      const handlePositions = [
        ['nw', el.x, el.y],
        ['ne', el.x + el.w, el.y],
        ['sw', el.x, el.y + el.h],
        ['se', el.x + el.w, el.y + el.h]
      ];
      handlePositions.forEach(([pos, hx, hy]) => {
        const handle = document.createElementNS(SVG_NS, 'rect');
        handle.setAttribute('x', hx - 5);
        handle.setAttribute('y', hy - 5);
        handle.setAttribute('width', 10);
        handle.setAttribute('height', 10);
        handle.setAttribute('class', 'wb-resize-handle');
        handle.dataset.pos = pos;
        handle.addEventListener('mousedown', (evt) => onResizeHandleDown(evt, el, pos));
        overlayLayer.appendChild(handle);
      });

      if (isBoxShape(el)) {
        Object.entries(getAnchors(el)).forEach(([key, pt]) => {
          if (key === 'C') return;
          const dot = document.createElementNS(SVG_NS, 'circle');
          dot.setAttribute('cx', pt.x);
          dot.setAttribute('cy', pt.y);
          dot.setAttribute('r', 3.5);
          dot.setAttribute('class', 'wb-anchor-dot');
          overlayLayer.appendChild(dot);
        });
      }
    } else if (isConnector(el)) {
      const p1 = resolveConnectorPoint(el, 'from');
      const p2 = resolveConnectorPoint(el, 'to');
      [
        ['from', p1],
        ['to', p2]
      ].forEach(([whichEnd, pt]) => {
        const handle = document.createElementNS(SVG_NS, 'circle');
        handle.setAttribute('cx', pt.x);
        handle.setAttribute('cy', pt.y);
        handle.setAttribute('r', 6);
        handle.setAttribute('class', 'wb-endpoint-handle');
        handle.addEventListener('mousedown', (evt) => onConnectorEndpointDown(evt, el, whichEnd));
        overlayLayer.appendChild(handle);
      });
    }
  }

  // ---------------------------------------------------------------------
  // Pointer interaction: creation
  // ---------------------------------------------------------------------
  svg.addEventListener('mousedown', onCanvasMouseDown);
  window.addEventListener('mousemove', onWindowMouseMove);
  window.addEventListener('mouseup', onWindowMouseUp);
  window.addEventListener('keydown', onKeyDown);

  function onCanvasMouseDown(evt) {
    if (!state.visible) return;
    if (evt.target.closest('#wb-toolbar') || evt.target.closest('#wb-reopen-tab')) return;
    const pt = svgPointFromEvent(evt);
    const tool = state.tool;

    if (tool === 'select') {
      const hit = hitTest(pt.x, pt.y);
      if (hit) {
        selectElement(hit.id);
        drag = { kind: 'move', id: hit.id, startX: pt.x, startY: pt.y, orig: deepClone(hit) };
      } else {
        selectElement(null);
      }
      return;
    }

    if (['rect', 'roundrect', 'ellipse', 'diamond'].includes(tool)) {
      const el = {
        id: uid(),
        type: tool,
        x: pt.x,
        y: pt.y,
        w: 1,
        h: 1,
        color: state.color,
        strokeWidth: state.strokeWidth,
        filled: state.filled
      };
      state.elements.push(el);
      drag = { kind: 'create-box', id: el.id, startX: pt.x, startY: pt.y };
      renderAll();
      return;
    }

    if (['arrow', 'line', 'curve'].includes(tool)) {
      const startShape = findShapeUnderPoint(pt.x, pt.y, null);
      let fromId = null;
      let fromAnchor = null;
      let startPt = pt;
      if (startShape) {
        const anchor = nearestAnchor(startShape, pt.x, pt.y);
        if (anchor.dist <= ANCHOR_SNAP_PX * 3) {
          fromId = startShape.id;
          fromAnchor = anchor.key;
          startPt = anchor.pt;
        }
      }
      const el = {
        id: uid(),
        type: tool,
        x1: startPt.x,
        y1: startPt.y,
        x2: pt.x,
        y2: pt.y,
        fromId,
        fromAnchor,
        toId: null,
        toAnchor: null,
        color: state.color,
        strokeWidth: state.strokeWidth
      };
      state.elements.push(el);
      drag = { kind: 'create-connector', id: el.id };
      renderAll();
      return;
    }

    if (tool === 'pen' || tool === 'highlighter') {
      const el = {
        id: uid(),
        type: tool,
        points: [pt],
        color: state.color,
        strokeWidth: tool === 'highlighter' ? 16 : state.strokeWidth
      };
      state.elements.push(el);
      drag = { kind: 'freehand', id: el.id };
      renderAll();
      return;
    }

    if (tool === 'text') {
      const el = {
        id: uid(),
        type: 'text',
        x: pt.x,
        y: pt.y,
        w: 160,
        h: 40,
        text: 'Double-click to edit',
        color: state.color,
        fontSize: 16
      };
      state.elements.push(el);
      renderAll();
      pushHistory();
      persist();
      selectElement(el.id);
      setTool('select');
      startTextEdit(el);
      return;
    }
  }

  function onWindowMouseMove(evt) {
    if (!drag || !state.visible) return;
    const pt = svgPointFromEvent(evt);

    if (drag.kind === 'move') {
      const el = getElement(drag.id);
      if (!el) return;
      const dx = pt.x - drag.startX;
      const dy = pt.y - drag.startY;
      if (isBoxShape(el)) {
        el.x = drag.orig.x + dx;
        el.y = drag.orig.y + dy;
      } else if (isConnector(el)) {
        el.x1 = drag.orig.x1 + dx;
        el.y1 = drag.orig.y1 + dy;
        el.x2 = drag.orig.x2 + dx;
        el.y2 = drag.orig.y2 + dy;
      } else if (el.points) {
        el.points = drag.orig.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
      }
      renderAll();
    } else if (drag.kind === 'create-box') {
      const el = getElement(drag.id);
      if (!el) return;
      el.x = Math.min(drag.startX, pt.x);
      el.y = Math.min(drag.startY, pt.y);
      el.w = Math.abs(pt.x - drag.startX);
      el.h = Math.abs(pt.y - drag.startY);
      renderAll();
    } else if (drag.kind === 'create-connector') {
      const el = getElement(drag.id);
      if (!el) return;
      const targetShape = findShapeUnderPoint(pt.x, pt.y, el.fromId);
      if (targetShape) {
        const anchor = nearestAnchor(targetShape, pt.x, pt.y);
        el.toId = targetShape.id;
        el.toAnchor = anchor.key;
        el.x2 = anchor.pt.x;
        el.y2 = anchor.pt.y;
      } else {
        el.toId = null;
        el.toAnchor = null;
        el.x2 = pt.x;
        el.y2 = pt.y;
      }
      renderAll();
    } else if (drag.kind === 'freehand') {
      const el = getElement(drag.id);
      if (!el) return;
      el.points.push(pt);
      renderAll();
    } else if (drag.kind === 'resize') {
      applyResize(drag, pt);
      renderAll();
    } else if (drag.kind === 'connector-endpoint') {
      const el = getElement(drag.id);
      if (!el) return;
      const targetShape = findShapeUnderPoint(pt.x, pt.y, null);
      const idKey = drag.whichEnd === 'from' ? 'fromId' : 'toId';
      const anchorKey = drag.whichEnd === 'from' ? 'fromAnchor' : 'toAnchor';
      const xKey = drag.whichEnd === 'from' ? 'x1' : 'x2';
      const yKey = drag.whichEnd === 'from' ? 'y1' : 'y2';
      if (targetShape) {
        const anchor = nearestAnchor(targetShape, pt.x, pt.y);
        el[idKey] = targetShape.id;
        el[anchorKey] = anchor.key;
        el[xKey] = anchor.pt.x;
        el[yKey] = anchor.pt.y;
      } else {
        el[idKey] = null;
        el[anchorKey] = null;
        el[xKey] = pt.x;
        el[yKey] = pt.y;
      }
      renderAll();
    }
  }

  function onWindowMouseUp() {
    if (!drag) return;
    const finishedKind = drag.kind;
    drag = null;
    if (finishedKind === 'create-box' || finishedKind === 'create-connector' || finishedKind === 'freehand') {
      setTool('select');
      const lastEl = state.elements[state.elements.length - 1];
      if (lastEl) selectElement(lastEl.id);
    }
    pushHistory();
    persist();
  }

  function onElementMouseDown(evt, el) {
    if (state.tool !== 'select') return;
    evt.stopPropagation();
    const pt = svgPointFromEvent(evt);
    selectElement(el.id);
    drag = { kind: 'move', id: el.id, startX: pt.x, startY: pt.y, orig: deepClone(el) };
  }

  function onElementDblClick(evt, el) {
    if (el.type === 'text') {
      evt.stopPropagation();
      selectElement(el.id);
      startTextEdit(el);
    }
  }

  function onResizeHandleDown(evt, el, pos) {
    evt.stopPropagation();
    drag = { kind: 'resize', id: el.id, pos, orig: deepClone(el) };
  }

  function applyResize(dragInfo, pt) {
    const el = getElement(dragInfo.id);
    if (!el) return;
    const o = dragInfo.orig;
    const left = o.x;
    const top = o.y;
    const right = o.x + o.w;
    const bottom = o.y + o.h;
    let newLeft = left,
      newTop = top,
      newRight = right,
      newBottom = bottom;
    if (dragInfo.pos.includes('w')) newLeft = pt.x;
    if (dragInfo.pos.includes('e')) newRight = pt.x;
    if (dragInfo.pos.includes('n')) newTop = pt.y;
    if (dragInfo.pos.includes('s')) newBottom = pt.y;
    el.x = Math.min(newLeft, newRight);
    el.y = Math.min(newTop, newBottom);
    el.w = Math.max(10, Math.abs(newRight - newLeft));
    el.h = Math.max(10, Math.abs(newBottom - newTop));
  }

  function onConnectorEndpointDown(evt, el, whichEnd) {
    evt.stopPropagation();
    drag = { kind: 'connector-endpoint', id: el.id, whichEnd };
  }

  function selectElement(id) {
    state.selectedId = id;
    renderOverlayLayer();
    if (id) {
      const el = getElement(id);
      if (el && el.color) {
        state.color = el.color;
        updateSwatchSelection();
      }
    }
  }

  function onKeyDown(evt) {
    if (!state.visible) return;
    const activeTag = shadow.activeElement && shadow.activeElement.tagName;
    if (activeTag === 'DIV' && shadow.activeElement.isContentEditable) return; // editing text

    if ((evt.key === 'Delete' || evt.key === 'Backspace') && state.selectedId) {
      evt.preventDefault();
      deleteSelected();
    } else if ((evt.metaKey || evt.ctrlKey) && evt.key.toLowerCase() === 'z' && !evt.shiftKey) {
      evt.preventDefault();
      undo();
    } else if ((evt.metaKey || evt.ctrlKey) && (evt.key.toLowerCase() === 'y' || (evt.key.toLowerCase() === 'z' && evt.shiftKey))) {
      evt.preventDefault();
      redo();
    } else if (evt.key === 'Escape') {
      selectElement(null);
      setTool('select');
    }
  }

  // ---------------------------------------------------------------------
  // Text editing (contenteditable overlay positioned above the foreignObject)
  // ---------------------------------------------------------------------
  function startTextEdit(el) {
    editorLayer.innerHTML = '';
    const div = document.createElement('div');
    div.className = 'wb-text-editor';
    div.contentEditable = 'true';
    div.style.left = el.x + 'px';
    div.style.top = el.y + 'px';
    div.style.width = Math.max(60, el.w) + 'px';
    div.style.minHeight = Math.max(24, el.h) + 'px';
    div.style.color = el.color;
    div.style.fontSize = (el.fontSize || 16) + 'px';
    div.textContent = el.text === 'Double-click to edit' ? '' : el.text;
    editorLayer.appendChild(div);
    div.focus();

    function commit() {
      el.text = div.textContent.trim() || 'Text';
      el.w = Math.max(60, div.offsetWidth);
      el.h = Math.max(24, div.offsetHeight);
      editorLayer.innerHTML = '';
      renderAll();
      pushHistory();
      persist();
    }

    div.addEventListener('blur', commit);
    div.addEventListener('keydown', (evt) => {
      if (evt.key === 'Enter' && !evt.shiftKey) {
        evt.preventDefault();
        div.blur();
      }
      evt.stopPropagation();
    });
  }

  // ---------------------------------------------------------------------
  // Export
  // ---------------------------------------------------------------------
  function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  function buildExportSvgString() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const clone = elementsLayer.cloneNode(true);
    const svgOut = document.createElementNS(SVG_NS, 'svg');
    svgOut.setAttribute('xmlns', SVG_NS);
    svgOut.setAttribute('width', w);
    svgOut.setAttribute('height', h);
    svgOut.setAttribute('viewBox', `0 0 ${w} ${h}`);
    const bg = document.createElementNS(SVG_NS, 'rect');
    bg.setAttribute('width', '100%');
    bg.setAttribute('height', '100%');
    bg.setAttribute('fill', state.mode === 'grid' ? '#F7F9FB' : 'none');
    svgOut.appendChild(bg);
    const defsClone = defs.cloneNode(true);
    svgOut.appendChild(defsClone);
    svgOut.appendChild(clone);
    return new XMLSerializer().serializeToString(svgOut);
  }

  function exportSVG() {
    const svgString = buildExportSvgString();
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    triggerDownload(blob, 'whiteboard-export.svg');
  }

  function exportJSON() {
    const data = {
      url: location.href,
      exportedAt: new Date().toISOString(),
      mode: state.mode,
      elements: state.elements
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    triggerDownload(blob, 'whiteboard-export.json');
  }

  function exportPNG() {
    const svgString = buildExportSvgString();
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = function () {
      const canvas = document.createElement('canvas');
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      const ctx = canvas.getContext('2d');
      if (state.mode !== 'grid') {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      } else {
        ctx.fillStyle = '#F7F9FB';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      ctx.drawImage(img, 0, 0);
      URL.revokeObjectURL(url);
      canvas.toBlob((blob) => {
        if (blob) triggerDownload(blob, 'whiteboard-export.png');
      }, 'image/png');
    };
    img.onerror = function (e) {
      console.error('Drawing Board: PNG export failed to rasterize SVG', e);
      URL.revokeObjectURL(url);
      alert('PNG export failed — try Export SVG instead.');
    };
    img.src = url;
  }

  // ---------------------------------------------------------------------
  // Visibility toggling
  // ---------------------------------------------------------------------
  function setVisible(visible) {
    state.visible = visible;
    host.style.display = visible ? 'block' : 'none';
  }

  function toggleVisibility() {
    setVisible(!state.visible);
  }

  // ---------------------------------------------------------------------
  // Messaging from background.js
  // ---------------------------------------------------------------------
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'WB_PING') {
      sendResponse({ alive: true });
      return true;
    }
    if (msg.type === 'WB_TOGGLE') {
      toggleVisibility();
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });

  window.__wbOverlayApi = { toggleVisibility, setVisible };

  // ---------------------------------------------------------------------
  // Boot
  // ---------------------------------------------------------------------
  loadPersisted();
  loadToolbarPosition();
})();
